﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ws_lab_05 {
    public class MSU {
        public string s;
        public int k;
        public float f;

        public MSU() { }
        public MSU(string s, int k, float f) {
            this.s = s;
            this.k = k;
            this.f = f;
        }
    }
}
