﻿namespace client {
    partial class Form1 {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent() {
            this.x1 = new System.Windows.Forms.TextBox();
            this.y1 = new System.Windows.Forms.TextBox();
            this.z1 = new System.Windows.Forms.TextBox();
            this.add = new System.Windows.Forms.Button();
            this.concat = new System.Windows.Forms.Button();
            this.z2 = new System.Windows.Forms.TextBox();
            this.y2 = new System.Windows.Forms.TextBox();
            this.x2 = new System.Windows.Forms.TextBox();
            this.s1 = new System.Windows.Forms.TextBox();
            this.d1 = new System.Windows.Forms.TextBox();
            this.i1 = new System.Windows.Forms.TextBox();
            this.i2 = new System.Windows.Forms.TextBox();
            this.d2 = new System.Windows.Forms.TextBox();
            this.s2 = new System.Windows.Forms.TextBox();
            this.sum = new System.Windows.Forms.Button();
            this.i3 = new System.Windows.Forms.TextBox();
            this.d3 = new System.Windows.Forms.TextBox();
            this.s3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // x1
            // 
            this.x1.Location = new System.Drawing.Point(12, 12);
            this.x1.Name = "x1";
            this.x1.Size = new System.Drawing.Size(100, 32);
            this.x1.TabIndex = 0;
            // 
            // y1
            // 
            this.y1.Location = new System.Drawing.Point(118, 12);
            this.y1.Name = "y1";
            this.y1.Size = new System.Drawing.Size(100, 32);
            this.y1.TabIndex = 1;
            // 
            // z1
            // 
            this.z1.Location = new System.Drawing.Point(369, 12);
            this.z1.Name = "z1";
            this.z1.Size = new System.Drawing.Size(100, 32);
            this.z1.TabIndex = 2;
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(224, 12);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(139, 32);
            this.add.TabIndex = 3;
            this.add.Text = "add";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // concat
            // 
            this.concat.Location = new System.Drawing.Point(224, 50);
            this.concat.Name = "concat";
            this.concat.Size = new System.Drawing.Size(139, 32);
            this.concat.TabIndex = 7;
            this.concat.Text = "concat";
            this.concat.UseVisualStyleBackColor = true;
            this.concat.Click += new System.EventHandler(this.concat_Click);
            // 
            // z2
            // 
            this.z2.Location = new System.Drawing.Point(369, 50);
            this.z2.Name = "z2";
            this.z2.Size = new System.Drawing.Size(100, 32);
            this.z2.TabIndex = 6;
            // 
            // y2
            // 
            this.y2.Location = new System.Drawing.Point(118, 50);
            this.y2.Name = "y2";
            this.y2.Size = new System.Drawing.Size(100, 32);
            this.y2.TabIndex = 5;
            // 
            // x2
            // 
            this.x2.Location = new System.Drawing.Point(12, 50);
            this.x2.Name = "x2";
            this.x2.Size = new System.Drawing.Size(100, 32);
            this.x2.TabIndex = 4;
            // 
            // s1
            // 
            this.s1.Location = new System.Drawing.Point(12, 120);
            this.s1.Name = "s1";
            this.s1.Size = new System.Drawing.Size(100, 32);
            this.s1.TabIndex = 8;
            // 
            // d1
            // 
            this.d1.Location = new System.Drawing.Point(12, 158);
            this.d1.Name = "d1";
            this.d1.Size = new System.Drawing.Size(100, 32);
            this.d1.TabIndex = 9;
            // 
            // i1
            // 
            this.i1.Location = new System.Drawing.Point(12, 196);
            this.i1.Name = "i1";
            this.i1.Size = new System.Drawing.Size(100, 32);
            this.i1.TabIndex = 10;
            // 
            // i2
            // 
            this.i2.Location = new System.Drawing.Point(118, 196);
            this.i2.Name = "i2";
            this.i2.Size = new System.Drawing.Size(100, 32);
            this.i2.TabIndex = 13;
            // 
            // d2
            // 
            this.d2.Location = new System.Drawing.Point(118, 158);
            this.d2.Name = "d2";
            this.d2.Size = new System.Drawing.Size(100, 32);
            this.d2.TabIndex = 12;
            // 
            // s2
            // 
            this.s2.Location = new System.Drawing.Point(118, 120);
            this.s2.Name = "s2";
            this.s2.Size = new System.Drawing.Size(100, 32);
            this.s2.TabIndex = 11;
            // 
            // sum
            // 
            this.sum.Location = new System.Drawing.Point(224, 120);
            this.sum.Name = "sum";
            this.sum.Size = new System.Drawing.Size(139, 108);
            this.sum.TabIndex = 14;
            this.sum.Text = "sum";
            this.sum.UseVisualStyleBackColor = true;
            this.sum.Click += new System.EventHandler(this.sum_Click);
            // 
            // i3
            // 
            this.i3.Location = new System.Drawing.Point(369, 196);
            this.i3.Name = "i3";
            this.i3.Size = new System.Drawing.Size(100, 32);
            this.i3.TabIndex = 17;
            // 
            // d3
            // 
            this.d3.Location = new System.Drawing.Point(369, 158);
            this.d3.Name = "d3";
            this.d3.Size = new System.Drawing.Size(100, 32);
            this.d3.TabIndex = 16;
            // 
            // s3
            // 
            this.s3.Location = new System.Drawing.Point(369, 122);
            this.s3.Name = "s3";
            this.s3.Size = new System.Drawing.Size(100, 32);
            this.s3.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 246);
            this.Controls.Add(this.i3);
            this.Controls.Add(this.d3);
            this.Controls.Add(this.s3);
            this.Controls.Add(this.sum);
            this.Controls.Add(this.i2);
            this.Controls.Add(this.d2);
            this.Controls.Add(this.s2);
            this.Controls.Add(this.i1);
            this.Controls.Add(this.d1);
            this.Controls.Add(this.s1);
            this.Controls.Add(this.concat);
            this.Controls.Add(this.z2);
            this.Controls.Add(this.y2);
            this.Controls.Add(this.x2);
            this.Controls.Add(this.add);
            this.Controls.Add(this.z1);
            this.Controls.Add(this.y1);
            this.Controls.Add(this.x1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "client";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox x1;
        private System.Windows.Forms.TextBox y1;
        private System.Windows.Forms.TextBox z1;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button concat;
        private System.Windows.Forms.TextBox z2;
        private System.Windows.Forms.TextBox y2;
        private System.Windows.Forms.TextBox x2;
        private System.Windows.Forms.TextBox s1;
        private System.Windows.Forms.TextBox d1;
        private System.Windows.Forms.TextBox i1;
        private System.Windows.Forms.TextBox i2;
        private System.Windows.Forms.TextBox d2;
        private System.Windows.Forms.TextBox s2;
        private System.Windows.Forms.Button sum;
        private System.Windows.Forms.TextBox i3;
        private System.Windows.Forms.TextBox d3;
        private System.Windows.Forms.TextBox s3;
    }
}

