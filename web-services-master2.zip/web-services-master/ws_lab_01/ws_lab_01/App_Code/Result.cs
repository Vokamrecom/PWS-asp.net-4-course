﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ws_lab_01.App_Code {
    public class Result {
        public static Stack<int> stack = new Stack<int>(new int[] { 0 });
        public static int result = 0;
    }
}