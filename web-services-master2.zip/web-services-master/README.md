# Web Services (ASP.NET)

## Labs
* Lab 01 - REST Service based on HTTP Handler
* Lab 02 - REST Service based on MVC WEB API
* Lab 03 - REST Service based on MVC WEB API + HATEOAS
* Lab 04 - SOAP Service
* Lab 05 - WCF Service
* Lab 06 - WCF Data Service
* Lab 07 - WCF Syndication Service (RSS/ATOM)
* Lab 08 - JSON RPC Service
