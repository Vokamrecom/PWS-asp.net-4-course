﻿namespace ws_lab_04.App_Code {
    public class A {
    }
}