﻿namespace client {
    partial class StartPage {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent() {
            this.getSum = new System.Windows.Forms.Button();
            this.x = new System.Windows.Forms.TextBox();
            this.y = new System.Windows.Forms.TextBox();
            this.result = new System.Windows.Forms.TextBox();
            this.getSumByProxy = new System.Windows.Forms.Button();
            this.s1 = new System.Windows.Forms.TextBox();
            this.s2 = new System.Windows.Forms.TextBox();
            this.i1 = new System.Windows.Forms.TextBox();
            this.i2 = new System.Windows.Forms.TextBox();
            this.d1 = new System.Windows.Forms.TextBox();
            this.d2 = new System.Windows.Forms.TextBox();
            this.MSU = new System.Windows.Forms.Button();
            this.result_3 = new System.Windows.Forms.TextBox();
            this.result_2 = new System.Windows.Forms.TextBox();
            this.result_1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // getSum
            // 
            this.getSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.getSum.Location = new System.Drawing.Point(222, 32);
            this.getSum.Name = "getSum";
            this.getSum.Size = new System.Drawing.Size(148, 96);
            this.getSum.TabIndex = 0;
            this.getSum.Text = "ref";
            this.getSum.UseVisualStyleBackColor = true;
            this.getSum.Click += new System.EventHandler(this.getSum_Click);
            // 
            // x
            // 
            this.x.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.x.Location = new System.Drawing.Point(29, 32);
            this.x.Name = "x";
            this.x.Size = new System.Drawing.Size(155, 36);
            this.x.TabIndex = 1;
            // 
            // y
            // 
            this.y.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.y.Location = new System.Drawing.Point(29, 92);
            this.y.Name = "y";
            this.y.Size = new System.Drawing.Size(155, 36);
            this.y.TabIndex = 2;
            // 
            // result
            // 
            this.result.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.result.Location = new System.Drawing.Point(562, 58);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(155, 36);
            this.result.TabIndex = 3;
            // 
            // getSumByProxy
            // 
            this.getSumByProxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.getSumByProxy.Location = new System.Drawing.Point(389, 32);
            this.getSumByProxy.Name = "getSumByProxy";
            this.getSumByProxy.Size = new System.Drawing.Size(148, 96);
            this.getSumByProxy.TabIndex = 4;
            this.getSumByProxy.Text = "proxy";
            this.getSumByProxy.UseVisualStyleBackColor = true;
            this.getSumByProxy.Click += new System.EventHandler(this.getSumByProxy_Click);
            // 
            // s1
            // 
            this.s1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.s1.Location = new System.Drawing.Point(29, 176);
            this.s1.Name = "s1";
            this.s1.Size = new System.Drawing.Size(155, 36);
            this.s1.TabIndex = 5;
            // 
            // s2
            // 
            this.s2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.s2.Location = new System.Drawing.Point(215, 176);
            this.s2.Name = "s2";
            this.s2.Size = new System.Drawing.Size(155, 36);
            this.s2.TabIndex = 6;
            // 
            // i1
            // 
            this.i1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.i1.Location = new System.Drawing.Point(29, 230);
            this.i1.Name = "i1";
            this.i1.Size = new System.Drawing.Size(155, 36);
            this.i1.TabIndex = 7;
            // 
            // i2
            // 
            this.i2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.i2.Location = new System.Drawing.Point(215, 230);
            this.i2.Name = "i2";
            this.i2.Size = new System.Drawing.Size(155, 36);
            this.i2.TabIndex = 8;
            // 
            // d1
            // 
            this.d1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.d1.Location = new System.Drawing.Point(29, 284);
            this.d1.Name = "d1";
            this.d1.Size = new System.Drawing.Size(155, 36);
            this.d1.TabIndex = 9;
            // 
            // d2
            // 
            this.d2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.d2.Location = new System.Drawing.Point(215, 284);
            this.d2.Name = "d2";
            this.d2.Size = new System.Drawing.Size(155, 36);
            this.d2.TabIndex = 10;
            // 
            // MSU
            // 
            this.MSU.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MSU.Location = new System.Drawing.Point(389, 170);
            this.MSU.Name = "MSU";
            this.MSU.Size = new System.Drawing.Size(148, 150);
            this.MSU.TabIndex = 11;
            this.MSU.Text = "MSU";
            this.MSU.UseVisualStyleBackColor = true;
            this.MSU.Click += new System.EventHandler(this.MSU_Click);
            // 
            // result_3
            // 
            this.result_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.result_3.Location = new System.Drawing.Point(562, 284);
            this.result_3.Name = "result_3";
            this.result_3.Size = new System.Drawing.Size(155, 36);
            this.result_3.TabIndex = 14;
            // 
            // result_2
            // 
            this.result_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.result_2.Location = new System.Drawing.Point(562, 230);
            this.result_2.Name = "result_2";
            this.result_2.Size = new System.Drawing.Size(155, 36);
            this.result_2.TabIndex = 13;
            // 
            // result_1
            // 
            this.result_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.result_1.Location = new System.Drawing.Point(562, 176);
            this.result_1.Name = "result_1";
            this.result_1.Size = new System.Drawing.Size(155, 36);
            this.result_1.TabIndex = 12;
            // 
            // StartPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(733, 407);
            this.Controls.Add(this.result_3);
            this.Controls.Add(this.result_2);
            this.Controls.Add(this.result_1);
            this.Controls.Add(this.MSU);
            this.Controls.Add(this.d2);
            this.Controls.Add(this.d1);
            this.Controls.Add(this.i2);
            this.Controls.Add(this.i1);
            this.Controls.Add(this.s2);
            this.Controls.Add(this.s1);
            this.Controls.Add(this.getSumByProxy);
            this.Controls.Add(this.result);
            this.Controls.Add(this.y);
            this.Controls.Add(this.x);
            this.Controls.Add(this.getSum);
            this.Name = "StartPage";
            this.Text = "Welcome";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button getSum;
        private System.Windows.Forms.TextBox x;
        private System.Windows.Forms.TextBox y;
        private System.Windows.Forms.TextBox result;
        private System.Windows.Forms.Button getSumByProxy;
        private System.Windows.Forms.TextBox s1;
        private System.Windows.Forms.TextBox s2;
        private System.Windows.Forms.TextBox i1;
        private System.Windows.Forms.TextBox i2;
        private System.Windows.Forms.TextBox d1;
        private System.Windows.Forms.TextBox d2;
        private System.Windows.Forms.Button MSU;
        private System.Windows.Forms.TextBox result_3;
        private System.Windows.Forms.TextBox result_2;
        private System.Windows.Forms.TextBox result_1;
    }
}

